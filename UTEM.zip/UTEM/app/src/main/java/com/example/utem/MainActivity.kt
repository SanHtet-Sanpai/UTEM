package com.example.utem

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.cardview.widget.CardView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val cv1 = findViewById<CardView>(R.id.card1)
        val cv2 = findViewById<CardView>(R.id.card2)
        val cv3 = findViewById<CardView>(R.id.card3)

        cv3.setOnClickListener(View.OnClickListener() {
            val intent = Intent(this, second::class.java)
            startActivity(intent)
        }
    });
}
}