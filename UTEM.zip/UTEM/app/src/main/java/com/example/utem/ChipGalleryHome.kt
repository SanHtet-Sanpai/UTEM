package com.example.utem

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class ChipGalleryHome : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chip_gallery_home)
    }
}